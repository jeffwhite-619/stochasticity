=============
stochasticity
=============

stochasticity provides various means of getting randomness. At this time 
there is only a coin flip feature. Other forms of randomness in the 
future could include latitude/longitude, colors, music
notes, and so on. (Not intended to replace Faker)
Example::

    #!/usr/bin/env python3

    from stochasticity.coin.coin import Coin
